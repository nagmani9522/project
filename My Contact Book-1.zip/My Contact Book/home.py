from tkinter import *
from tkinter.ttk import *
import login

class HomeWindow(Tk):
    def __init__(self, *args, **kwargs):
        Tk.__init__(self, *args, **kwargs)

        self.title("Home")
        self.state("zoomed")

        s = Style()
        
        s.configure('Header.TFrame', background = 'blue')
        s.configure('Header.TLabel', background = 'blue', foreground = 'white', font = ('Arial', 25))
        s.configure('Navigation.TButton', width = 20, font = ('Arial', 15))
        
        header_frame = Frame(self, style = 'Header.TFrame')
        header_frame.pack(fill = X)

        heder_label = Label(header_frame, text = "My Contact Book", style = 'Header.TLabel')
        heder_label.pack(pady = 10)

        navigation_frame = Frame(self, style = 'Header.TFrame')
        navigation_frame.pack(side = LEFT, fill = Y)

        manage_contacts_button = Button(navigation_frame, text = "Manage Contacts", style = 'Navigation.TButton')
        manage_contacts_button.pack(pady = 1, ipady = 10)

        change_password_button = Button(navigation_frame, text = "Change Password", style = 'Navigation.TButton')
        change_password_button.pack(pady = 1, ipady = 10)

        logout_button = Button(navigation_frame, text = "Logout", style = 'Navigation.TButton', command = self.logout_button_click)
        logout_button.pack(pady = 1, ipady = 10)

    def logout_button_click(self):
        self.destroy()
        login.LoginWindow()

        

        
